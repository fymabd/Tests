const { EmbedBuilder } = require("discord.js");
const UserQuests = require("../models/UserQuests.js");
const { staffManager } = require("../config.js");

module.exports = {
  name: "خذ",
  async execute(message, args) {
    if (!message.member.roles.cache.has(staffManager)) 
      return message.reply("**ماتتوب؟.**");

    const user = message.mentions.users.first();
    const amount = parseInt(args[1]);
    if (!user || isNaN(amount)) return message.reply("**منشن الشخص طيب واكتب الكمية؟**");

    let userData = await UserQuests.findOne({ userId: user.id });
    if (!userData) userData = new UserQuests({ userId: user.id, quests: [], points: 0 });

    userData.points += amount;
    await userData.save();

    const embed = new EmbedBuilder()
      .setDescription(`**تم اضافة نقاط الى ${user.username} نقاطه الحاليه هي :** \`${userData.points}\``)
      .setColor("#115581");

    message.reply({ embeds: [embed] });
  }
};