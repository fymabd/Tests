const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require("discord.js");

module.exports = {
    name: "كنترول",
    async execute(message) {
        if (message.author.id !== "1212361716785217560") return;

        const embed = new EmbedBuilder()
    .setAuthor({ 
        name: message.guild.name, 
        iconURL: message.guild.iconURL({ dynamic: true }) 
    })
    .setDescription("**اهلا بك في طاقم الادارة ، لفهم كل شيء اضغط على زر ℹ️ .**")
    .setThumbnail(message.guild.iconURL({ dynamic: true }))
    .setColor("#115581")
    .setFooter({ text: "Made by 3tb.js" });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("rank")
                .setLabel("ترقية")
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId("info")
                .setLabel("ℹ️")
                .setStyle(ButtonStyle.Secondary)
        );

        await message.channel.send({ embeds: [embed], components: [row] });
    },
};