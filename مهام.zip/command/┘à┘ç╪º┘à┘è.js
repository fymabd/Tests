const { EmbedBuilder } = require("discord.js");
const UserQuests = require("../models/UserQuests.js");
const { allowedRoleId } = require("../config.js");
const QUESTS = require("../quests.js");

module.exports = {
  name: "مهامي",
  async execute(message, args) {
    if (!message.member.roles.cache.has(allowedRoleId))
      return message.reply("**انت مو من الادارة.**");

    let userData = await UserQuests.findOne({ userId: message.author.id });

    if (!userData) {
      const msgQuest = QUESTS.filter(q => q.type === "message")[Math.floor(Math.random() * QUESTS.filter(q => q.type === "message").length)];
      const tktQuest = QUESTS.filter(q => q.type === "ticket")[Math.floor(Math.random() * QUESTS.filter(q => q.type === "ticket").length)];

      userData = new UserQuests({
        userId: message.author.id,
        quests: [msgQuest, tktQuest]
      });

      await userData.save();
    }

    const embed = new EmbedBuilder()
      .setTitle("**هذه مهماتك الحالية.**")
      .setColor("#115581");

    const msgQuest = userData.quests.find(q => q.type === "message");
    const tktQuest = userData.quests.find(q => q.type === "ticket");

    if (msgQuest) {
      const percent = Math.floor((msgQuest.progress / msgQuest.goal) * 100);
      embed.addFields({
        name: `1 - ${msgQuest.completed ? "✅" : "❌"} ${msgQuest.name}`,
        value: `**التقدم:** ${msgQuest.progress}/${msgQuest.goal} (${percent}%)\n**المكافأة:** ${msgQuest.reward} نقطة`
      });
    }

    if (tktQuest) {
      const percent = Math.floor((tktQuest.progress / tktQuest.goal) * 100);
      embed.addFields({
        name: `2 - ${tktQuest.completed ? "✅" : "❌"} ${tktQuest.name}`,
        value: `**التقدم:** ${tktQuest.progress}/${tktQuest.goal} (${percent}%)\n**المكافأة:** ${tktQuest.reward} نقطة`
      });
    }

    message.reply({ embeds: [embed] });
  }
};