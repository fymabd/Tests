const { EmbedBuilder } = require("discord.js");
const UserQuests = require("../models/UserQuests.js");

module.exports = {
  name: "نقاطي",
  async execute(message, args) {
    let user;

    if (message.mentions.users.size) {
      user = message.mentions.users.first();
    } else if (args[0]) {
      user = await message.client.users.fetch(args[0]).catch(() => null);
    } else {
      user = message.author;
    }

    if (!user) return message.reply("**العضو مو موجود اصلا.**");

    const userData = await UserQuests.findOne({ userId: user.id });
    const points = userData?.points || 0;

    const embed = new EmbedBuilder()
    .setAuthor({
        name: user.username,
        iconURL: user.displayAvatarURL()
    })
      .setTitle(`**نقاط الادارة.**`)
      .setDescription(`**نقاطك :** \`${points}\``)
      .setThumbnail(message.guild.iconURL())
      .setColor("#115581")
      .setFooter({
          text: user.username,
          iconURL: user.displayAvatarURL()
      });

    message.reply({ embeds: [embed] });
  }
};