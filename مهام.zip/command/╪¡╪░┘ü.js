const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const UserQuests = require("../models/UserQuests.js");
const QUESTS = require("../quests.js");
const { staffManager } = require("../config.js");

function genquest() {
  const msgQuests = QUESTS.filter(q => q.type === "message");
  const tktQuests = QUESTS.filter(q => q.type === "ticket");
  const msgquest = msgQuests[Math.floor(Math.random() * msgQuests.length)];
  const tktquest = tktQuests[Math.floor(Math.random() * tktQuests.length)];
  return [
    { ...msgquest, progress: 0, completed: false },
    { ...tktquest, progress: 0, completed: false }
  ];
}

module.exports = {
  name: "حذف",
  async execute(message, args) {
    if (!message.member.roles.cache.has(staffManager)) 
      return message.reply("**ماتتوب؟.**");

    const user = message.mentions.users.first() || null;

    const embed = new EmbedBuilder()
      .setDescription(user 
        ? `اختر ما تريد اعادة تغييره لـ ${user.username}` 
        : "اختر ما تريد اعادة تغييره للجميع")
      .setColor("#115581");

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(user ? "reset_points_user" : "reset_points_all")
          .setLabel(user ? "اعادة نقاط العضو" : "اعادة نقاط الكل")
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(user ? "change_tasks_user" : "change_tasks_all")
          .setLabel(user ? "اعادة مهام العضو" : "اعادة مهام الكل")
          .setStyle(ButtonStyle.Danger)
      );

    const msg = await message.reply({ embeds: [embed], components: [row] });

    const collector = msg.createMessageComponentCollector({ time: 60000 });

    collector.on("collect", async (interaction) => {
      if (!interaction.member.roles.cache.has(staffManager)) 
        return interaction.reply({ content: "**ماتتوب؟.**", ephemeral: true });

      const disabledRow = new ActionRowBuilder()
        .addComponents(row.components.map(btn => btn.setDisabled(true)));

      if (interaction.customId === "reset_points_user" && user) {
        let userData = await UserQuests.findOne({ userId: user.id });
        if (userData) { userData.points = 0; await userData.save(); }
        embed.setDescription(`**تم اعادة تعيين النقاط من ${user.username} بنجاح.**`);
      }

      if (interaction.customId === "change_tasks_user" && user) {
        let userData = await UserQuests.findOne({ userId: user.id });
        if (userData) { userData.quests = genquest(); await userData.save(); }
        embed.setDescription(`**تم تغيير المهام لـ ${user.username} بنجاح.**`);
      }

      if (interaction.customId === "reset_points_all") {
        const allUsers = await UserQuests.find({});
        for (const u of allUsers) { u.points = 0; await u.save(); }
        embed.setDescription("**تم اعادة تعيين النقاط للجميع بنجاح.**");
      }

      if (interaction.customId === "change_tasks_all") {
        const allUsers = await UserQuests.find({});
        for (const u of allUsers) { u.quests = genquest(); await u.save(); }
        embed.setDescription("**تم تغيير المهام للجميع بنجاح.**");
      }

      await interaction.update({ embeds: [embed], components: [disabledRow] });
    });
  }
};