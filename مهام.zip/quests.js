module.exports = [
  { name: 'قم بإرسال 100 رسالة', type: 'message', goal: 100, reward: 1 },
  { name: 'قم باستلام 2 تذكرة', type: 'ticket', goal: 2, reward: 1 }
];