const mongoose = require("mongoose");

const questSchema = new mongoose.Schema({
    name: { type: String, required: true },
    type: { type: String, enum: ["message", "ticket"], required: true },
    goal: { type: Number, required: true },
    reward: { type: Number, default: 1 },
    progress: { type: Number, default: 0 },
    completed: { type: Boolean, default: false }
});

const userQuestsSchema = new mongoose.Schema({
    userId: { type: String, required: true, unique: true },
    quests: { type: [questSchema], default: [] },
    points: { type: Number, default: 0 }
});

module.exports = mongoose.model("UserQuests", userQuestsSchema);