const mongoose = require("mongoose");
const { db } = require("../config.js");

module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    console.log(`✅ The bot is online as ${client.user.username}`);

    try {
      await mongoose.connect(db, { useNewUrlParser: true, useUnifiedTopology: true });
      console.log("✅ Connected to MongoDB");
    } catch (err) {
      console.log("❌ Error connecting to MongoDB:", err);
    }
  }
};