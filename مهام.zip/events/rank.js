const UserQuests = require("../models/UserQuests.js");
const config = require("../config.js");

const ranks = [
  { roleId: "", points: 1 },
  { roleId: "", points: 2 },
  { roleId: "", points: 3 },
  { roleId: "", points: 4 },
  { roleId: "", points: 5 },
  { roleId: "", points: 6 },
  { roleId: "", points: 7 },
  { roleId: "", points: 8 },
  { roleId: "", points: 9 },
  { roleId: "", points: 10 },
  { roleId: "", points: 11 },
  { roleId: "", points: 12 }
];

module.exports = {
  name: "interactionCreate",
  async execute(client, interaction) {
    if (!interaction.isButton()) return;
    if (interaction.customId !== "rank") return;

    const userId = interaction.user.id;

    try {
      let user = await UserQuests.findOne({ userId });
      if (!user)
        return interaction.reply({ content: "**روح اشحذ يافقير.**", ephemeral: true });

      const member = await interaction.guild.members.fetch(userId).catch(() => null);
      if (!member)
        return interaction.reply({ content: "ماقدرت اجد العضو بالسيرفر.", ephemeral: true });

      let currentIndex = -1;
      for (let i = 0; i < ranks.length; i++) {
        if (member.roles.cache.has(ranks[i].roleId)) {
          currentIndex = i;
        }
      }

      let nextRank = currentIndex === -1 ? ranks[0] : ranks[currentIndex + 1];
      if (!nextRank)
        return interaction.reply({ content: "**انت دلخ؟؟ اعلى رتبة و تبي زيادة!!!**", ephemeral: true });

      if (user.points < nextRank.points)
        return interaction.reply({ content: `**تحتاج ${nextRank.points} نقطة عشان تترقى.**`, ephemeral: true });

      user.points -= nextRank.points;
      await user.save();
      await member.roles.add(nextRank.roleId);

      const logChannel = interaction.guild.channels.cache.get(config.logUpgradeId);
      if (logChannel) {
        logChannel.send({
          content: `**تم ترقية ${member} الى <@&${nextRank.roleId}> **`,
        });
        setTimeout(() => {
          logChannel.send({
            files: [config.lineLink],
          });
        }, 500);
      }

      return interaction.reply({ content: "**مبروك يولد والله و طلعت قويي🤣**", ephemeral: true });
    } catch (err) {
      console.error(err);
      return interaction.reply({ content: "حدث خطأ حاول لاحقاً.", ephemeral: true });
    }
  },
};