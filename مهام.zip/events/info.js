const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "interactionCreate",
    async execute(client, interaction){
        
        if(!interaction.isButton()) return;
        if(interaction.customId == "info"){

        const embed = new EmbedBuilder()
    .setAuthor({ 
        name: interaction.guild.name, 
        iconURL: interaction.guild.iconURL({ dynamic: true }) 
    })
    .setDescription(`** نظام الترقيات الجديدة : **

من <@&1408397088500350979> ➝ <@&1408397067478634537>  
كل 3 نقاط = ترقية  

من <@&1408397067478634537> ➝ <@&1408397050214875158>  
كل 7 نقاط = ترقية  

من <@&1408397050214875158> ➝ <@&1408397029943672854>  
كل 10 نقاط = ترقية  

من <@&1408397029943672854> ➝ <@&1408397017683591279>  
كل 12 نقطة = ترقية  

من <@&1408397017683591279> ➝ <@&1408397004131794978>  
كل 14 نقطة = ترقية  

من <@&1408397004131794978> ➝ <@&1408396997861572698>  
كل 16 نقطة = ترقية  

من <@&1408396997861572698> ➝ القسم الأخير  
كل 20 نقطة = ترقية`)
    .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
    .setColor("#115581")
    .setFooter({ text: "Made by 3tb.js" });
        
        await interaction.reply({
            embeds: [embed],
            ephemeral: true
        });
        
        }
    },
};