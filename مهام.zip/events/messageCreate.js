const UserQuests = require("../models/UserQuests.js");
const QUESTS = require("../quests.js");
const { 
  allowedRoleId, 
  messagesChannelId, 
  ticketsCategoryId, 
  monitoredBotId, 
  prefix,
  logChannelId
} = require("../config.js");
const { EmbedBuilder } = require("discord.js");

function genQuest() {
  const msgQuest = QUESTS.filter(q => q.type === "message")[Math.floor(Math.random() * QUESTS.filter(q => q.type === "message").length)];
  const tktQuest = QUESTS.filter(q => q.type === "ticket")[Math.floor(Math.random() * QUESTS.filter(q => q.type === "ticket").length)];
  return [
    { ...msgQuest, progress: 0, completed: false },
    { ...tktQuest, progress: 0, completed: false }
  ];
}

async function logQuestCompletion(client, userData, quest) {
  if (!quest.completed) return;
  const logChannel = await client.channels.fetch(logChannelId).catch(() => null);
  if (!logChannel) return;

  const embed = new EmbedBuilder()
    .setTitle("اكمال المهمة")
    .setColor("#115518")
    .setDescription(`**تم انتهاء المهمة من قبل :** <@${userData.userId}>
**المهمة :** ${quest.name}
**المكافأة :** ${quest.reward} نقطه.`)
    .setTimestamp();

  logChannel.send({ embeds: [embed] });
}

module.exports = {
  name: "messageCreate",
  async execute(client, message) {
    if (message.author.bot && message.author.id !== monitoredBotId) return;

    const userId = message.author.id;
    let userData = await UserQuests.findOne({ userId });

    if (!userData) userData = new UserQuests({ userId, quests: genQuest(), points: 0 });

    userData.quests = userData.quests.map(quest => {
    if (quest.completed) {
        const newQuest = genQuest()[0];
        return { ...newQuest, completed: false };
    }
    return quest;
});

userData.lastCompleted = Date.now();
await userData.save();

    if (message.channel.id === messagesChannelId &&
        !message.author.bot &&
        !message.content.startsWith(prefix)) {

      const member = await message.guild.members.fetch(userId).catch(() => null);
      if (!member || !member.roles.cache.has(allowedRoleId)) return;

      const msgQuest = userData.quests.find(q => q.type === "message" && !q.completed);
      if (msgQuest) {
        msgQuest.progress += 1;
        if (msgQuest.progress >= msgQuest.goal) {
          msgQuest.progress = msgQuest.goal;
          msgQuest.completed = true;
          userData.points += msgQuest.reward || 1;
          await logQuestCompletion(client, userData, msgQuest);
        }
      }
      await userData.save();
    }

    if (message.channel.parentId === ticketsCategoryId &&
        message.author.id === monitoredBotId &&
        message.content.includes("تم استلام التذكرة بواسطة")) {

      const mentionedUser = message.mentions.users.first();
      if (!mentionedUser) return;

      let userData = await UserQuests.findOne({ userId: mentionedUser.id });
      if (!userData) return;

      const tktQuest = userData.quests.find(q => q.type === "ticket" && !q.completed);
      if (tktQuest) {
        tktQuest.progress += 1;
        if (tktQuest.progress >= tktQuest.goal) {
          tktQuest.progress = tktQuest.goal;
          tktQuest.completed = true;
          userData.points += tktQuest.reward || 1;
          await logQuestCompletion(client, userData, tktQuest);
        }
        await userData.save();
      }
    }

    if (message.content.startsWith(prefix)) {
      const args = message.content.slice(prefix.length).trim().split(/ +/);
      const commandName = args.shift().toLowerCase();
      const command = client.commands.get(commandName);
      if (!command) return;
      try { await command.execute(message, args, client); } 
      catch { message.reply("❌ حدث خطأ أثناء تنفيذ الأمر."); }
    }
  }
};