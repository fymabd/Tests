module.exports = {
    token: "",
    prefix: "",
    staffManager: "",
    allowedRoleId: "",
    messagesChannelId: "",
    ticketsCategoryId: "",
    monitoredBotId: "",
    logChannelId: "",
    logUpgradeId: "",
    lineLink: "",
    db: ""
}