// فهرس أوامر المستخدمين
const { handleMentionsCommand } = require('./handleMentionsCommand');

module.exports = {
    handleMentionsCommand
};