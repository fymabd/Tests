const { ApplicationCommandOptionType, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'type',
    description: 'تعديل نوع متجر موجود',
    options: [
        {
            name: 'action',
            description: 'نوع العملية',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                { name: 'عرض الأنواع المتاحة', value: 'list' },
                { name: 'تعديل نوع موجود', value: 'edit' },
                { name: 'حذف نوع', value: 'delete' }
            ]
        },
        {
            name: 'type_id',
            description: 'معرف نوع المتجر (للتعديل أو الحذف)',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'name',
            description: 'اسم نوع المتجر الجديد',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'category',
            description: 'كاتاغوري المتجر الجديد',
            type: ApplicationCommandOptionType.Channel,
            required: false
        },
        {
            name: 'role',
            description: 'رتبة المتجر الجديدة',
            type: ApplicationCommandOptionType.Role,
            required: false
        },
        {
            name: 'emoji',
            description: 'إيموجي المتجر الجديد',
            type: ApplicationCommandOptionType.String,
            required: false
        },
        {
            name: 'price',
            description: 'سعر إنشاء المتجر الجديد',
            type: ApplicationCommandOptionType.Integer,
            required: false,
            min_value: 1
        },
        {
            name: 'here_mentions',
            description: 'عدد منشنات Here الافتراضية الجديد',
            type: ApplicationCommandOptionType.Integer,
            required: false,
            min_value: 0
        },
        {
            name: 'everyone_mentions',
            description: 'عدد منشنات Everyone الافتراضية الجديد',
            type: ApplicationCommandOptionType.Integer,
            required: false,
            min_value: 0
        }
    ],

    async execute(interaction, db, config, createStandardEmbed) {
        // التحقق من صلاحيات الإدارة
        if (!interaction.member.permissions.has('Administrator')) {
            return interaction.reply({ 
                content: 'ليس لديك صلاحية لاستخدام هذا الأمر!', 
                ephemeral: true 
            });
        }

        const action = interaction.options.getString('action');

        try {
            if (action === 'list') {
                await this.listShopTypes(interaction, db, createStandardEmbed);
            } else if (action === 'edit') {
                await this.editShopType(interaction, db, config, createStandardEmbed);
            } else if (action === 'delete') {
                await this.deleteShopType(interaction, db, config, createStandardEmbed);
            }
        } catch (error) {
            console.error('خطأ في أمر type:', error);
            
            const errorEmbed = createStandardEmbed(
                '❌ خطأ في العملية', 
                'حدث خطأ أثناء تنفيذ العملية. يرجى المحاولة مرة أخرى.', 
                interaction.guild
            );
            
            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    },

    async listShopTypes(interaction, db, createStandardEmbed) {
        const shopTypes = await db.get('shop_types') || [];
        
        if (shopTypes.length === 0) {
            const embed = createStandardEmbed(
                '📋 قائمة أنواع المتاجر', 
                'لا توجد أنواع متاجر مسجلة حالياً.', 
                interaction.guild
            );
            
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        const embed = createStandardEmbed(
            '📋 قائمة أنواع المتاجر', 
            'إليك جميع أنواع المتاجر المسجلة:', 
            interaction.guild
        );

        for (const typeId of shopTypes) {
            const typeData = await db.get(`shop_type_${typeId}`);
            if (typeData) {
                embed.addFields({
                    name: `${typeData.emoji} ${typeData.name}`,
                    value: `**المعرف:** \`${typeId}\`\n**السعر:** ${typeData.price} عملة\n**Here:** ${typeData.here} | **Everyone:** ${typeData.everyone}`,
                    inline: true
                });
            }
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async editShopType(interaction, db, config, createStandardEmbed) {
        const typeId = interaction.options.getString('type_id');
        
        if (!typeId) {
            return interaction.reply({
                content: '❌ يجب تحديد معرف نوع المتجر للتعديل!',
                ephemeral: true
            });
        }

        const typeData = await db.get(`shop_type_${typeId}`);
        if (!typeData) {
            return interaction.reply({
                content: '❌ لم يتم العثور على نوع المتجر المحدد!',
                ephemeral: true
            });
        }

        // جمع التعديلات
        const updates = {};
        const name = interaction.options.getString('name');
        const category = interaction.options.getChannel('category');
        const role = interaction.options.getRole('role');
        const emoji = interaction.options.getString('emoji');
        const price = interaction.options.getInteger('price');
        const hereMentions = interaction.options.getInteger('here_mentions');
        const everyoneMentions = interaction.options.getInteger('everyone_mentions');

        if (name) updates.name = name;
        if (category) {
            if (category.type !== 4) {
                return interaction.reply({
                    content: '❌ يجب أن يكون الخيار المحدد كاتاغوري وليس قناة عادية!',
                    ephemeral: true
                });
            }
            updates.categoryId = category.id;
        }
        if (role) updates.roleId = role.id;
        if (emoji) updates.emoji = emoji;
        if (price) updates.price = price;
        if (hereMentions !== null) updates.here = hereMentions;
        if (everyoneMentions !== null) updates.everyone = everyoneMentions;

        if (Object.keys(updates).length === 0) {
            return interaction.reply({
                content: '❌ لم يتم تحديد أي تعديلات!',
                ephemeral: true
            });
        }

        // تطبيق التعديلات
        const updatedTypeData = { ...typeData, ...updates, updatedAt: Date.now() };
        await db.set(`shop_type_${typeId}`, updatedTypeData);

        const embed = createStandardEmbed(
            '✅ تم تعديل نوع المتجر بنجاح', 
            `تم تعديل نوع المتجر **${updatedTypeData.name}** بنجاح!`, 
            interaction.guild
        );

        // عرض التعديلات
        const changes = [];
        if (updates.name) changes.push(`الاسم: ${updates.name}`);
        if (updates.categoryId) changes.push(`الكاتاغوري: <#${updates.categoryId}>`);
        if (updates.roleId) changes.push(`الرتبة: <@&${updates.roleId}>`);
        if (updates.emoji) changes.push(`الإيموجي: ${updates.emoji}`);
        if (updates.price) changes.push(`السعر: ${updates.price} عملة`);
        if (updates.here !== undefined) changes.push(`منشنات Here: ${updates.here}`);
        if (updates.everyone !== undefined) changes.push(`منشنات Everyone: ${updates.everyone}`);

        embed.addFields({
            name: 'التعديلات المطبقة:',
            value: changes.join('\n'),
            inline: false
        });

        await interaction.reply({ embeds: [embed], ephemeral: true });

        // إرسال لوق
        try {
            if (config.log) {
                const logChannel = interaction.guild.channels.cache.get(config.log);
                if (logChannel) {
                    const logEmbed = createStandardEmbed(
                        '✏️ تم تعديل نوع متجر', 
                        `تم تعديل نوع المتجر **${updatedTypeData.name}** بواسطة <@${interaction.user.id}>`, 
                        interaction.guild
                    );
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
        } catch (error) {
            console.error('خطأ في إرسال لوق تعديل نوع المتجر:', error);
        }
    },

    async deleteShopType(interaction, db, config, createStandardEmbed) {
        const typeId = interaction.options.getString('type_id');
        
        if (!typeId) {
            return interaction.reply({
                content: '❌ يجب تحديد معرف نوع المتجر للحذف!',
                ephemeral: true
            });
        }

        const typeData = await db.get(`shop_type_${typeId}`);
        if (!typeData) {
            return interaction.reply({
                content: '❌ لم يتم العثور على نوع المتجر المحدد!',
                ephemeral: true
            });
        }

        // حذف نوع المتجر
        await db.delete(`shop_type_${typeId}`);

        // إزالة من قائمة الأنواع
        let shopTypes = await db.get('shop_types') || [];
        shopTypes = shopTypes.filter(id => id !== typeId);
        await db.set('shop_types', shopTypes);

        const embed = createStandardEmbed(
            '✅ تم حذف نوع المتجر بنجاح', 
            `تم حذف نوع المتجر **${typeData.name}** نهائياً!`, 
            interaction.guild
        );

        await interaction.reply({ embeds: [embed], ephemeral: true });

        // إرسال لوق
        try {
            if (config.log) {
                const logChannel = interaction.guild.channels.cache.get(config.log);
                if (logChannel) {
                    const logEmbed = createStandardEmbed(
                        '🗑️ تم حذف نوع متجر', 
                        `تم حذف نوع المتجر **${typeData.name}** بواسطة <@${interaction.user.id}>`, 
                        interaction.guild
                    );
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }
        } catch (error) {
            console.error('خطأ في إرسال لوق حذف نوع المتجر:', error);
        }
    }
};