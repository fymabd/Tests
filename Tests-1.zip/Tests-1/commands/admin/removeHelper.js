// هذا الملف تم استبداله بنظام الأزرار في shop-bot.js
// للاستخدام الحالي، استخدم زر "تنظيم المساعدين" في لوحة إدارة المتجر

async function removeHelper(interaction, db, config) {
    await interaction.deferReply();
    
    await interaction.editReply({
        content: '⚠️ هذا الأمر غير متاح. استخدم زر **تنظيم المساعدين** في لوحة إدارة المتجر أو الأوامر الجديدة.',
        ephemeral: true
    });
}

module.exports = { removeHelper };