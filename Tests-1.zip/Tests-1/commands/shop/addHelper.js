// هذا الملف تم استبداله بنظام الأزرار في shop-bot.js
// للاستخدام الحالي، استخدم زر "تنظيم المساعدين" في لوحة إدارة المتجر

async function addHelper(interaction, db, config, createStandardEmbed) {
    await interaction.deferReply();
    
    await interaction.editReply({
        content: '⚠️ هذا الأمر غير متاح. استخدم زر **تنظيم المساعدين** في لوحة إدارة المتجر.',
        ephemeral: true
    });
}

module.exports = { addHelper };