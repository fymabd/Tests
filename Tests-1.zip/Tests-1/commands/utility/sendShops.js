const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = async function sendShops(interaction, db, config, types, createStandardEmbed) {
    // التحقق من صلاحيات الإدارة
    if (!interaction.member.roles.cache.has(config.Admin)) {
        return interaction.reply({ content: 'ليس لديك صلاحية لاستخدام هذا الأمر!', ephemeral: true });
    }

    const embed = createStandardEmbed(
        '🏪 بانل المتاجر',
        'إدارة المتاجر والخدمات المتعلقة بها',
        interaction.guild
    );

    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('open_shop_ticket')
                .setLabel('🟨 🎫 فتح تذكرة متجر')
                .setStyle(ButtonStyle.Secondary)
        );

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('view_shop_prices')
                .setLabel('🟨 💰 أسعار المتاجر')
                .setStyle(ButtonStyle.Secondary)
        );

    try {
        await interaction.channel.send({ embeds: [embed], components: [row1, row2] });
        await interaction.reply({ content: '✅ تم إرسال بانل المتاجر!', ephemeral: true });
    } catch (error) {
        console.error('خطأ في إرسال بانل المتاجر:', error);
        await interaction.reply({ content: '❌ حدث خطأ أثناء إرسال البانل!', ephemeral: true });
    }
};