const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = async function sendPanels(interaction, db, config, types, createStandardEmbed) {
    // التحقق من صلاحيات الإدارة
    if (!interaction.member.roles.cache.has(config.Admin)) {
        return interaction.reply({ content: 'ليس لديك صلاحية لاستخدام هذا الأمر!', ephemeral: true });
    }

    const embed = createStandardEmbed(
        '🏪 لوحة التحكم الرئيسية',
        'اختر الخدمة التي تريدها:',
        interaction.guild
    );

    // ترتيب الأزرار عمودياً (كل زر في صف منفصل)
    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('open_shop_ticket')
                .setLabel('🟨 🏪 متجر')
                .setStyle(ButtonStyle.Secondary) // مظهر أصفر مع إيموجي
        );

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('open_orders_ticket')
                .setLabel('🟨 📋 طلبات')
                .setStyle(ButtonStyle.Secondary) // مظهر أصفر مع إيموجي
        );


    try {
        await interaction.channel.send({ 
            embeds: [embed], 
            components: [row1, row2] 
        });
        await interaction.reply({ content: '✅ تم إرسال لوحة التحكم الرئيسية!', ephemeral: true });
    } catch (error) {
        console.error('خطأ في إرسال البانل:', error);
        await interaction.reply({ content: '❌ حدث خطأ أثناء إرسال البانل!', ephemeral: true });
    }
};