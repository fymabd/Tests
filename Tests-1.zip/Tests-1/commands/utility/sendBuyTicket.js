const { ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getAllShopTypes } = require('../../utils/shopTypes');

// دالة إرسال تذكرة شراء متجر  
async function sendBuyTicket(interaction, db, config, createStandardEmbed) {
    const data = await db.get(`buy_shop_ticket_${interaction.member.id}`);
    if (data) {
        return await interaction.reply({
            content: `**من فضلك عندك تذكره لا يمكنك فتح تذكره اخره - <#${data.channelId}>**`,
            ephemeral: true
        });
    }

    await interaction.deferReply({ ephemeral: true });
    await interaction.editReply({ content: `Please wait ....` });

    const channel = await interaction.guild.channels.create({
        name: `buy shop ${interaction.user.tag}`,
        type: ChannelType.GuildText,
        parent: config.catagory,
        topic: "تـكـت شـراء مـتـجـر",
        permissionOverwrites: [
            {
                id: interaction.user.id,
                allow: [
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.ViewChannel,
                ],
            },
            {
                id: interaction.guild.id,
                deny: [
                    PermissionFlagsBits.AttachFiles,
                    PermissionFlagsBits.SendMessages,
                    PermissionFlagsBits.ViewChannel,
                ],
            },
        ],
    });

    await db.set(`buy_shop_ticket_${interaction.member.id}`, {
        userId: interaction.member.id,
        channelId: channel.id
    });

    const embedAboveButtons = createStandardEmbed('🏪 بانل اختيار نوع المتجر', '**قـم بـإخـتـيـار نـوع الـمـتـجـر مـن الأزرار أدنـاه**', interaction.guild);
    embedAboveButtons.setImage(config.info);

    // الحصول على أنواع المتاجر الديناميكية
    const allShopTypes = await getAllShopTypes(db);
    console.log(`عدد أنواع المتاجر المتاحة: ${allShopTypes.length}`);
    
    if (!allShopTypes || allShopTypes.length === 0) {
        console.error('❌ لا توجد أنواع متاجر متاحة!');
        return await interaction.editReply({
            content: '❌ عذراً، لا توجد أنواع متاجر متاحة حالياً. يرجى المحاولة لاحقاً.'
        });
    }

    const typeRows = [];
    
    // إنشاء أزرار في صفوف (حد أقصى 5 أزرار لكل صف، 5 صفوف كحد أقصى)
    for (let i = 0; i < allShopTypes.length && i < 25; i += 5) {
        const row = new ActionRowBuilder();
        
        // إضافة حد أقصى 5 أزرار لكل صف
        for (let j = i; j < Math.min(i + 5, allShopTypes.length) && j < 25; j++) {
            const type = allShopTypes[j];
            console.log(`إضافة نوع متجر: ${type.name} - ID: ${type.id}`);
            
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`shop_type_${type.id}`)
                    .setLabel(`${type.badge} ${type.name} - ${type.price} كرديت`)
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🟨')
            );
        }
        
        if (row.components.length > 0) {
            typeRows.push(row);
        }
        
        // Discord يسمح بـ5 صفوف كحد أقصى، يمكن وضع زر الإغلاق في آخر صف به مكان
        if (typeRows.length >= 5) break;
    }

    // إضافة زر الإغلاق - محاولة وضعه في آخر صف إذا كان هناك مكان
    if (typeRows.length > 0 && typeRows[typeRows.length - 1].components.length < 5) {
        // إضافة زر الإغلاق في آخر صف
        typeRows[typeRows.length - 1].addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('إغلاق التذكرة')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒')
        );
    } else if (typeRows.length < 5) {
        // إنشاء صف منفصل لزر الإغلاق
        const closeRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('close_ticket')
                    .setLabel('إغلاق التذكرة')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒')
            );
        typeRows.push(closeRow);
    }

    console.log(`عدد الصفوف المُنشأة: ${typeRows.length}`);
    await channel.send({ embeds: [embedAboveButtons], components: typeRows });

    await interaction.editReply({
        content: `**تـم إنـشـاء تـكـت شـراء مـتـجـر بـ نـجـاح** ${channel}`
    });
}

module.exports = { sendBuyTicket };