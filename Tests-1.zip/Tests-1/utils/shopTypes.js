
const { types } = require('../types.js');

/**
 * دالة موحدة للحصول على أنواع المتاجر من قاعدة البيانات مع احتياطي من الملف المشفر
 */
async function getAllShopTypes(db) {
    try {
        // الحصول على أنواع المتاجر من قاعدة البيانات
        const dbShopTypes = await db.get('shop_types') || [];
        const shopTypes = [];

        // جلب بيانات كل نوع من قاعدة البيانات
        for (const typeId of dbShopTypes) {
            const typeData = await db.get(`shop_type_${typeId}`);
            if (typeData) {
                // تحويل بنية البيانات لتكون متوافقة مع النظام الحالي
                shopTypes.push({
                    id: typeData.categoryId, // استخدام categoryId كـ id للقناة الفرعية
                    typeId: typeId, // حفظ المعرف الأصلي
                    name: typeData.name,
                    role: typeData.roleId,
                    shop: 30, // قيمة افتراضية (سيتم تحديثها لاحقاً)
                    every: typeData.everyone,
                    here: typeData.here,
                    price: typeData.price,
                    badge: typeData.emoji,
                    isDbType: true // تحديد أنه من قاعدة البيانات
                });
            }
        }

        // إضافة الأنواع المُشفرة كاحتياطي إذا لم توجد أنواع في قاعدة البيانات
        if (shopTypes.length === 0) {
            console.log('لا توجد أنواع متاجر في قاعدة البيانات، استخدام الأنواع المُشفرة');
            
            // التحقق من أن types موجود ومن النوع الصحيح
            if (!types || !Array.isArray(types)) {
                console.error('خطأ: types غير موجود أو ليس array');
                return [];
            }
            
            return types.map(type => ({
                ...type,
                isDbType: false
            }));
        }

        // دمج الأنواع المُشفرة مع أنواع قاعدة البيانات
        if (types && Array.isArray(types)) {
            const hardcodedTypes = types.map(type => ({
                ...type,
                isDbType: false
            }));
            return [...shopTypes, ...hardcodedTypes];
        }

        return shopTypes;

    } catch (error) {
        console.error('خطأ في جلب أنواع المتاجر من قاعدة البيانات:', error);
        // في حالة الخطأ، استخدام الأنواع المُشفرة
        if (types && Array.isArray(types)) {
            return types.map(type => ({
                ...type,
                isDbType: false
            }));
        }
        return [];
    }
}

/**
 * البحث عن نوع متجر بواسطة المعرف
 */
async function getShopTypeById(db, typeId) {
    const allTypes = await getAllShopTypes(db);
    return allTypes.find(type => type.id === typeId || type.typeId === typeId);
}

/**
 * الحصول على أنواع المتاجر من قاعدة البيانات فقط
 */
async function getDatabaseShopTypes(db) {
    try {
        const dbShopTypes = await db.get('shop_types') || [];
        const shopTypes = [];

        for (const typeId of dbShopTypes) {
            const typeData = await db.get(`shop_type_${typeId}`);
            if (typeData) {
                shopTypes.push({
                    id: typeId,
                    ...typeData
                });
            }
        }

        return shopTypes;
    } catch (error) {
        console.error('خطأ في جلب أنواع المتاجر من قاعدة البيانات:', error);
        return [];
    }
}

/**
 * الحصول على الأنواع المُشفرة فقط
 */
function getHardcodedShopTypes() {
    return types || [];
}

module.exports = {
    getAllShopTypes,
    getShopTypeById,
    getDatabaseShopTypes,
    getHardcodedShopTypes
};
