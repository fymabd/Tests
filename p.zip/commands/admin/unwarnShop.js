// دالة إزالة تحذيرات المتاجر
async function unwarnShop(interaction, db, createStandardEmbed) {
    await interaction.deferReply({ ephemeral: true });
    const shop = interaction.options.getChannel('shop');
    const amount = interaction.options.getNumber('amount');

    const data = await db.get(`shop_${shop.id}`);
    if (!data) {
        return interaction.editReply({ content: `** هـذة الـروم لـيـسـت مـتـجـرا **` });
    }

    if (!data.warns) data.warns = 0;
    if (data.warns - amount < 0) {
        return interaction.editReply({ content: `** بـتـشـيـل ${amount} كـيـف و عـدد تـحـذيـرات المـتـجـر ${data.warns} اصـلا **` });
    }

    await db.sub(`shop_${shop.id}.warns`, amount);

    // التحقق من إمكانية تفعيل المتجر إذا انخفضت التحذيرات لأقل من 5
    const newWarns = data.warns - amount;
    if (newWarns < 5 && data.status === "0") {
        // تفعيل المتجر تلقائياً
        await shop.permissionOverwrites.edit(interaction.guild.roles.everyone, {
            ViewChannel: true,
        });
        await db.set(`shop_${shop.id}.status`, "1");
        
        // حذف disableUntil إذا كان موجوداً
        await db.delete(`shop_${shop.id}.disableUntil`);
        
        await shop.send({ content: `**✅ تم تفعيل المتجر تلقائياً بسبب انخفاض التحذيرات إلى ${newWarns}**` });
        
        // إرسال سجل للقناة الإدارية
        const logChannel = interaction.guild.channels.cache.get(data.logChannelId || interaction.guild.channels.cache.find(ch => ch.name.includes('log'))?.id);
        if (logChannel) {
            const adminLogEmbed = createStandardEmbed('🔄 تفعيل تلقائي للمتجر', `**السبب:** انخفاض التحذيرات\n**المتجر:** ${shop.name}\n**المالك:** <@${data.owner}>`, interaction.guild);
            adminLogEmbed.addFields(
                { name: 'التحذيرات الجديدة', value: newWarns.toString(), inline: true },
                { name: 'تم بواسطة', value: `<@${interaction.user.id}>`, inline: true }
            );
            await logChannel.send({ embeds: [adminLogEmbed] });
        }
    }

    await interaction.editReply({ content: `**تـم ازالـة ${amount} تـحـذيـرات مـن مـتـجـر بـ نـجـاح ${shop}**` });
    await shop.send({ content: `**تـم ازالـة ${amount} تـحـذيـرات مـن المـتـجـر**` });
}

module.exports = { unwarnShop };