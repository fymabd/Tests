# Discord Shop Bot

## Overview

A Discord bot designed to manage and automate shop systems within Discord servers. The bot provides comprehensive shop management features including shop creation, mention limits, payment systems, order processing, and administrative controls. It supports Arabic language interface and integrates with various Discord features to create a complete e-commerce ecosystem within Discord servers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Discord.js v14**: Core framework for Discord API interactions
- **Node.js**: Runtime environment with minimum version 16.0.0
- **QuickDB with JSON Driver**: Local file-based database for data persistence

### Shop Management System
- **Multi-tier Shop Types**: Five predefined shop categories (PLATINUM, GRAND MASTER, MASTER, DIAMOND, BRONZE) with different pricing and mention limits
- **Dynamic Shop Creation**: Automated channel creation with proper permissions and role assignments
- **Mention Limit System**: Tracks and manages @everyone, @here, and shop-specific mentions per store
- **Shop Status Management**: Enable/disable shops with automatic enforcement based on warning levels

### Payment and Pricing System
- **ProBot Integration**: Leverages ProBot for payment processing and tax calculations
- **Dynamic Pricing**: Configurable prices for different services (mentions, warnings removal, shop creation)
- **Tax Calculation**: Built-in tax computation for transactions
- **Payment Verification**: Automated payment confirmation through bot monitoring

### Warning and Moderation System
- **Progressive Warning System**: Automatic shop disabling at 5 warnings, deletion at 7 warnings
- **Warning Removal**: Paid service to remove warnings with automatic shop reactivation
- **Administrative Controls**: Comprehensive admin commands for shop management

### Ticket System Architecture
- **Automated Ticket Creation**: Category-based ticket generation for different services
- **Permission Management**: Dynamic permission assignment for ticket participants
- **Order Processing**: Structured order handling with admin approval workflow

### Content Filtering
- **Word Encryption**: Automatic replacement of filtered Arabic words with encoded alternatives
- **Configurable Filter List**: Expandable list of words to be automatically encrypted

### Data Storage Structure
- **Shop Data**: Stores owner, type, mention counts, warnings, status, and creation date
- **Payment Tracking**: Records payment status for various services
- **Helper Management**: Tracks shop assistants and their permissions

### Command Architecture
- **Modular Command System**: Organized into admin, shop, user, and utility command categories
- **Slash Command Integration**: Full Discord slash command support with autocomplete
- **Permission-based Access**: Role-based command restrictions for different user levels

### Integration Points
- **Webhook Support**: Planned auto-send system using webhooks for scheduled messages
- **Canvas Integration**: Image generation capabilities for shop graphics
- **Express Server**: HTTP server for potential web interface or API endpoints

## External Dependencies

### Core Discord Libraries
- **discord.js v14.22.1**: Main Discord API wrapper
- **@discordjs/builders**: Command and component builders
- **@discordjs/collection**: Enhanced Map-like collections

### Database and Storage
- **quick.db v9.1.7**: Simple JSON-based database with SQLite-like interface
- **write-file-atomic**: Atomic file writing for data integrity

### Utility Libraries
- **ms v2.1.3**: Time parsing and formatting
- **node-fetch v3.2.6**: HTTP request handling
- **canvas v2.11.2**: Image generation and manipulation

### Web Framework
- **express v4.18.2**: HTTP server for web endpoints

### AI and Image Generation
- **prodia v0.1.1**: AI image generation service integration

### Development Dependencies
- **@types/node v18.0.6**: TypeScript definitions for Node.js