
// دالة تعطيل المتاجر (دائم فقط)
async function handleDisableCommand(interaction, db, createStandardEmbed) {
    await interaction.deferReply({ ephemeral: true });

    const action = interaction.options.getString('action') || 'disable';
    const shop = interaction.options.getChannel('shop') || interaction.channel;
    const reason = interaction.options.getString('reason');

    const datap = await db.get(`shop_${shop.id}`);
    if (!datap) {
        return interaction.editReply('**هذا الروم ليس متجر**');
    }

    if (action === 'disable') {
        if (datap.status === "0") {
            return interaction.editReply('**هذا الروم معطل بالفعل**');
        }

        await shop.permissionOverwrites.edit(interaction.guild.roles.everyone, {
            ViewChannel: false,
        });

        await db.set(`shop_${shop.id}.status`, "0");

        // حذف أي بيانات تعطيل مؤقت قديمة
        await db.delete(`shop_${shop.id}.disableUntil`);

        const embedlog = createStandardEmbed(`تم تعطيل المتجر`, `المسؤول: <@${interaction.user.id}>`, interaction.guild);
        embedlog.addFields(
            { name: 'السبب', value: reason || 'لم يتم تحديد سبب', inline: true },
            { name: 'ملاحظة', value: 'المتجر معطل دائماً. يمكن لصاحب المتجر أو المساعدين تفعيله بالدفع', inline: true }
        );

        await shop.send({ content: `<@${datap.owner}>`, embeds: [embedlog] });
        await interaction.editReply('**تم تعطيل المتجر بنجاح (دائم)**');

        // إرسال سجل للقناة الإدارية
        const logChannel = interaction.guild.channels.cache.get(config.log);
        if (logChannel) {
            const adminLogEmbed = createStandardEmbed('⛔ تم تعطيل متجر', `**المسؤول:** <@${interaction.user.id}>\n**المتجر:** ${shop.name}\n**المالك:** <@${datap.owner}>`, interaction.guild);
            adminLogEmbed.addFields(
                { name: 'السبب', value: reason || 'لم يتم تحديد سبب', inline: true },
                { name: 'النوع', value: 'تعطيل دائم', inline: true }
            );
            await logChannel.send({ content: '@here', embeds: [adminLogEmbed] });
        }

    } else if (action === 'check_status') {
        const status = datap.status === "1" ? "مفعل ✅" : "معطل ❌";

        const statusEmbed = createStandardEmbed('حالة المتجر', `**الحالة الحالية:** ${status}`, interaction.guild);

        if (datap.status === "0") {
            statusEmbed.addFields({
                name: 'ملاحظة:',
                value: 'المتجر معطل دائماً. يمكن لصاحب المتجر أو المساعدين تفعيله عن طريق دفع 5000 كرديت',
                inline: false
            });
        }

        await interaction.editReply({ embeds: [statusEmbed] });
    }
}

module.exports = { handleDisableCommand };
