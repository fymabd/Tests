const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = async function sendActions(interaction, db, config, types, createStandardEmbed) {
    // التحقق من صلاحيات الإدارة
    if (!interaction.member.roles.cache.has(config.Admin)) {
        return interaction.reply({ content: 'ليس لديك صلاحية لاستخدام هذا الأمر!', ephemeral: true });
    }

    const embed = createStandardEmbed(
        '⚙️ بانل الإدارة',
        'إدارة الخدمات والعمليات الإدارية',
        interaction.guild
    );

    try {
        await interaction.channel.send({ embeds: [embed] });
        await interaction.reply({ content: '✅ تم إرسال بانل الإدارة!', ephemeral: true });
    } catch (error) {
        console.error('خطأ في إرسال بانل الإدارة:', error);
        await interaction.reply({ content: '❌ حدث خطأ أثناء إرسال البانل!', ephemeral: true });
    }
};