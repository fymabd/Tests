const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'price',
    description: 'عرض لوحة الأسعار الشاملة لجميع الخدمات',

    async execute(interaction, db, config, createStandardEmbed) {
        try {
            const embed = createStandardEmbed(
                '💰 لوحة الأسعار الشاملة', 
                'اختر نوع الأسعار التي تريد عرضها:', 
                interaction.guild
            );

            // اللون العشوائي يتم تطبيقه تلقائياً في createStandardEmbed

            // ترتيب الأزرار عمودياً كما هو مطلوب في الوثيقة

            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('order_prices')
                        .setLabel('🟨 📋 أسعار الطلبات')
                        .setStyle(ButtonStyle.Secondary)
                );

            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('shop_prices')
                        .setLabel('🟨 🏪 أسعار المتاجر')
                        .setStyle(ButtonStyle.Secondary)
                );

            const row3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('additional_services')
                        .setLabel('🟨 ⚙️ خدمات إضافية (إزالة تحذيرات، شراء منشنات)')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.reply({
                embeds: [embed],
                components: [row1, row2, row3]
            });

        } catch (error) {
            console.error('خطأ في عرض لوحة الأسعار:', error);
            
            const errorEmbed = createStandardEmbed(
                '❌ خطأ في عرض الأسعار', 
                'حدث خطأ أثناء عرض لوحة الأسعار. يرجى المحاولة مرة أخرى.', 
                interaction.guild
            );
            
            await interaction.reply({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    }
};